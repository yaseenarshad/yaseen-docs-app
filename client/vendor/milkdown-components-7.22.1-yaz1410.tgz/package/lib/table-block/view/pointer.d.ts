import type { EditorView } from '@milkdown/prose/view';
import type { Refs } from './types';
export declare const TABLE_HANDLE_PLACE = "milkdown-table-handle-place";
export declare function usePointerHandlers(refs: Refs, view?: EditorView): {
    pointerMove: (e: PointerEvent) => void;
    pointerLeave: () => void;
    pointerReplay: () => void;
};
//# sourceMappingURL=pointer.d.ts.map