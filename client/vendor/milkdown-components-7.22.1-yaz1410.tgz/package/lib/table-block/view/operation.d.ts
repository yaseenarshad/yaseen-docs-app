import type { Ctx } from '@milkdown/ctx';
import type { Refs } from './types';
export declare const TABLE_HANDLE_MENU = "milkdown-table-handle-menu";
export interface TableHandleMenuDetail {
    x: number;
    y: number;
    pos: number;
}
export declare function useOperation(refs: Refs, ctx?: Ctx, getPos?: () => number | undefined): {
    selectCol: (e: MouseEvent) => void;
    selectRow: (e: MouseEvent) => void;
};
//# sourceMappingURL=operation.d.ts.map