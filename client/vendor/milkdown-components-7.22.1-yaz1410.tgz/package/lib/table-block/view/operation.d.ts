import type { Ctx } from '@milkdown/ctx';
import type { Command, EditorState } from '@milkdown/prose/state';
import type { Refs } from './types';
export type MenuItem = [
    label: string,
    onPointerdown: (e: PointerEvent) => void,
    disabled?: (state: EditorState) => boolean
];
export declare function sortRows(direction: 1 | -1): Command;
export declare const duplicateRows: Command;
export declare function useOperation(refs: Refs, ctx?: Ctx, getPos?: () => number | undefined): {
    onAddRow: () => void;
    onAddCol: () => void;
    selectCol: () => void;
    selectRow: () => void;
    colMenu: MenuItem[][];
    rowMenu: MenuItem[][];
};
//# sourceMappingURL=operation.d.ts.map