import type { Ctx } from '@milkdown/ctx'
import type { Node } from '@milkdown/prose/model'
import type { EditorView } from '@milkdown/prose/view'

import {
  defineComponent,
  ref,
  type VNodeRef,
  h,
  onMounted,
  onUnmounted,
  type Ref,
} from 'vue'

import type { TableBlockConfig } from '../config'
import type { CellIndex, DragInfo, Refs } from './types'

import { Icon } from '../../__internal__/components/icon'
import { keepAlive } from '../../__internal__/keep-alive'
import { useDragHandlers } from './drag'
import { useOperation } from './operation'
import { usePointerHandlers } from './pointer'
import { recoveryStateBetweenUpdate } from './utils'

keepAlive(h)

type TableBlockProps = {
  view: EditorView
  ctx: Ctx
  getPos: () => number | undefined
  config: TableBlockConfig
  onMount: (div: Element) => void
  node: Ref<Node>
}

export const TableBlock = defineComponent<TableBlockProps>({
  props: {
    view: {
      type: Object,
      required: true,
    },
    ctx: {
      type: Object,
      required: true,
    },
    getPos: {
      type: Function,
      required: true,
    },
    config: {
      type: Object,
      required: true,
    },
    onMount: {
      type: Function,
      required: true,
    },
    node: {
      type: Object,
      required: true,
    },
  },
  setup({ view, node, ctx, getPos, config, onMount }) {
    const contentWrapperRef = ref<HTMLElement>()
    const contentWrapperFunctionRef: VNodeRef = (div) => {
      if (div == null) return
      if (div instanceof HTMLElement) {
        contentWrapperRef.value = div
        onMount(div)
      } else {
        contentWrapperRef.value = undefined
      }
    }
    const colHandleRef = ref<HTMLDivElement>()
    const rowHandleRef = ref<HTMLDivElement>()
    const xLineHandleRef = ref<HTMLDivElement>()
    const yLineHandleRef = ref<HTMLDivElement>()
    const tableWrapperRef = ref<HTMLDivElement>()
    const dragPreviewRef = ref<HTMLDivElement>()
    const hoverIndex = ref<CellIndex>([0, 0])
    const dragInfo = ref<DragInfo>()

    const refs: Refs = {
      dragPreviewRef,
      tableWrapperRef,
      contentWrapperRef,
      yLineHandleRef,
      xLineHandleRef,
      colHandleRef,
      rowHandleRef,
      hoverIndex,
      dragInfo,
    }

    const { pointerLeave, pointerMove, pointerReplay } = usePointerHandlers(
      refs,
      view
    )
    const { dragRow, dragCol } = useDragHandlers(refs, ctx, getPos)
    const { selectCol, selectRow } = useOperation(refs, ctx, getPos)
    // YAZ-3801, YAZ-3820: a right-click on a handle does what a click does (it selects, then asks
    // the app for its table menu), not the note's own right-click. Its mousedown (a ⌃-click is a
    // right-click on macOS) stays off the editor, so the editor does not move the selection.
    const contextMenu = (select: (e: MouseEvent) => void) => (e: MouseEvent) => {
      e.preventDefault()
      e.stopPropagation()
      select(e)
    }
    const rightDown = (e: MouseEvent) => {
      if (e.button !== 0 || e.ctrlKey) e.stopPropagation()
    }

    // YAZ-4169: the block (the node view's DOM) is the sideways scroll box. Its scroll places the
    // shown handles again (`pointerReplay`).
    let scroller: Element | null | undefined
    onMounted(() => {
      scroller = tableWrapperRef.value?.closest('.milkdown-table-block')
      scroller?.addEventListener('scroll', pointerReplay, { passive: true })
      requestAnimationFrame(() => {
        // This is a wordaround to keep the popover open when click the select col/row button
        if (view.editable) recoveryStateBetweenUpdate(refs, view, node.value)
      })
    })

    onUnmounted(() => scroller?.removeEventListener('scroll', pointerReplay))

    return () => {
      return (
        <div
          onDragstart={(e) => e.preventDefault()}
          onDragover={(e) => e.preventDefault()}
          onDragleave={(e) => e.preventDefault()}
          onPointermove={pointerMove}
          onPointerleave={pointerLeave}
        >
          <div
            data-show="false"
            contenteditable="false"
            draggable="true"
            data-role="col-drag-handle"
            class="handle cell-handle"
            onDragstart={dragCol}
            onClick={selectCol}
            onContextmenu={contextMenu(selectCol)}
            onMousedown={rightDown}
            onPointerdown={(e: PointerEvent) => e.stopPropagation()}
            onPointermove={(e: PointerEvent) => e.stopPropagation()}
            ref={colHandleRef}
          >
            <Icon icon={config.renderButton('col_drag_handle')} />
          </div>
          <div
            data-show="false"
            contenteditable="false"
            draggable="true"
            data-role="row-drag-handle"
            class="handle cell-handle"
            onDragstart={dragRow}
            onClick={selectRow}
            onContextmenu={contextMenu(selectRow)}
            onMousedown={rightDown}
            onPointerdown={(e: PointerEvent) => e.stopPropagation()}
            onPointermove={(e: PointerEvent) => e.stopPropagation()}
            ref={rowHandleRef}
          >
            <Icon icon={config.renderButton('row_drag_handle')} />
          </div>
          <div class="table-wrapper" ref={tableWrapperRef}>
            <div
              data-show="false"
              class="drag-preview"
              data-direction="vertical"
              ref={dragPreviewRef}
            >
              <table>
                <tbody></tbody>
              </table>
            </div>
            {/* YAZ-3800 (2D): the drop lines of a row or column drag. The "+" insert buttons are gone. */}
            <div
              data-show="false"
              contenteditable="false"
              data-display-type="indicator"
              data-role="x-line-drag-handle"
              class="handle line-handle"
              onPointermove={(e: PointerEvent) => e.stopPropagation()}
              ref={xLineHandleRef}
            />
            <div
              data-show="false"
              contenteditable="false"
              data-display-type="indicator"
              data-role="y-line-drag-handle"
              class="handle line-handle"
              onPointermove={(e: PointerEvent) => e.stopPropagation()}
              ref={yLineHandleRef}
            />
            <table ref={contentWrapperFunctionRef} class="children"></table>
          </div>
        </div>
      )
    }
  },
})
