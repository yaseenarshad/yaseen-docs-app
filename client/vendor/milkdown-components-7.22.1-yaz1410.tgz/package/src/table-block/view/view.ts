import type { Ctx } from '@milkdown/ctx'
import type { Node } from '@milkdown/prose/model'
import type {
  EditorView,
  NodeView,
  NodeViewConstructor,
  ViewMutationRecord,
} from '@milkdown/prose/view'

import { tableSchema } from '@milkdown/preset-gfm'
import { updateColumnsOnResize } from '@milkdown/prose/tables'
import { $view } from '@milkdown/utils'
import { createApp, shallowRef, type App, type ShallowRef } from 'vue'

import { withMeta } from '../../__internal__/meta'
import { tableBlockConfig } from '../config'
import { TableBlock } from './component'

export class TableNodeView implements NodeView {
  dom: HTMLElement
  contentDOM: HTMLElement
  app: App
  #colgroup: HTMLElement

  nodeRef: ShallowRef<Node>

  constructor(
    public ctx: Ctx,
    public node: Node,
    public view: EditorView,
    public getPos: () => number | undefined
  ) {
    const dom = document.createElement('div')
    dom.className = 'milkdown-table-block'

    const contentDOM = document.createElement('tbody')
    this.contentDOM = contentDOM
    contentDOM.setAttribute('data-content-dom', 'true')
    contentDOM.classList.add('content-dom')
    // YAZ-3696 D2: the column widths (`colwidth`). It must be the table's first child:
    // `columnResizing` writes the widths there while a column edge drags.
    const colgroup = document.createElement('colgroup')
    this.#colgroup = colgroup
    this.nodeRef = shallowRef(node)

    const app = createApp(TableBlock, {
      view,
      ctx,
      getPos,
      config: ctx.get(tableBlockConfig.key),
      onMount: (div: Element) => {
        div.appendChild(colgroup)
        div.appendChild(contentDOM)
        this.#updateColumns()
      },
      node: this.nodeRef,
    })
    app.mount(dom)
    this.app = app

    this.dom = dom
  }

  update(node: Node) {
    if (node.type !== this.node.type) return false

    // YAZ-3696 B4: an unchanged node (a decoration change: fold, line numbers) keeps the view.
    // `false` here made ProseMirror rebuild the whole Vue table on each decoration change.
    if (node.sameMarkup(this.node) && node.content.eq(this.node.content))
      return true

    this.node = node
    this.nodeRef.value = node
    this.#updateColumns()

    return true
  }

  // The `prosemirror-tables` rule (as in its own `TableView`), so the table looks the same during
  // and after a drag. 100 is `columnResizing`'s `defaultCellMinWidth`. A table with no width keeps
  // its old look: the full width and no minimum width.
  #updateColumns() {
    const table = this.contentDOM.parentElement
    if (!table) return
    updateColumnsOnResize(this.node, this.#colgroup, table, 100)
    const widths = Array.from(
      this.#colgroup.children,
      (col) => (col as HTMLElement).style.width
    )
    if (!widths.some(Boolean)) table.style.minWidth = ''
  }

  stopEvent(e: Event) {
    if (e.type === 'drop' || e.type.startsWith('drag')) return true

    if (e.type === 'mousedown' || e.type === 'pointerdown') {
      if (e.target instanceof Element && e.target.closest('button')) return true
      // YAZ-3696 B2: a mousedown in a cell goes to ProseMirror, so `tableEditing` can start a
      // cell selection drag. A plain click puts the caret in the cell (the old `#handleClick`
      // selected the cell paragraph as a node instead).
    }

    return false
  }

  ignoreMutation(mutation: ViewMutationRecord) {
    if (!this.dom || !this.contentDOM) return true

    if ((mutation.type as unknown) === 'selection') return false

    if (this.contentDOM === mutation.target && mutation.type === 'attributes')
      return true

    if (this.contentDOM.contains(mutation.target)) return false

    return true
  }

  destroy() {
    this.app.unmount()
    this.dom.remove()
    this.contentDOM.remove()
  }
}

export const tableBlockView = $view(
  tableSchema.node,
  (ctx): NodeViewConstructor => {
    return (initialNode, view, getPos) => {
      return new TableNodeView(ctx, initialNode, view, getPos)
    }
  }
)

withMeta(tableBlockView, {
  displayName: 'NodeView<table-block>',
  group: 'TableBlock',
})
