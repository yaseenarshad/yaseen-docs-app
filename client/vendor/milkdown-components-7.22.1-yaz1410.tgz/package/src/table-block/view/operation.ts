import type { Ctx } from '@milkdown/ctx'
import type { Node } from '@milkdown/prose/model'
import type { Command } from '@milkdown/prose/state'

import { commandsCtx, editorViewCtx, type CmdKey } from '@milkdown/core'
import {
  addColAfterCommand,
  addColBeforeCommand,
  addRowAfterCommand,
  addRowBeforeCommand,
  deleteSelectedCellsCommand,
  selectCol as selectColumn,
  selectColCommand,
  selectRowCommand,
  setAlignCommand,
} from '@milkdown/preset-gfm'
import {
  deleteCellSelection,
  isInTable,
  selectedRect,
} from '@milkdown/prose/tables'

import type { Refs } from './types'

/** One labeled menu item (YAZ-3696 D9): its text and what a pointerdown on it does. */
export type MenuItem = [label: string, onPointerdown: (e: PointerEvent) => void]

// "9" before "10"; case and accents do not count.
const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' })

/**
 * YAZ-3696 D9: sort the body rows by the text of the selected column. The header row stays
 * first, empty cells go last, equal cells keep their order. The whole rows move, so each cell
 * keeps its attributes. One transaction, which selects the column again. GFM cells have no
 * colspan, so the column is the cell index in each row.
 */
export function sortRows(direction: 1 | -1): Command {
  return (state, dispatch) => {
    if (!isInTable(state)) return false
    const { table, tableStart, left } = selectedRect(state)
    const rows: Node[] = []
    table.forEach((row, _, index) => {
      if (index > 0) rows.push(row)
    })
    const sorted = rows
      .map((row, index) => ({ row, index, text: row.child(left).textContent.trim() }))
      .sort((a, b) => {
        if (!a.text !== !b.text) return a.text ? -1 : 1
        return direction * collator.compare(a.text, b.text) || a.index - b.index
      })
      .map(({ row }) => row)
    if (sorted.every((row, index) => row === rows[index])) return true
    if (dispatch) {
      const from = tableStart + table.firstChild!.nodeSize
      const tr = state.tr.replaceWith(from, tableStart + table.content.size, sorted)
      dispatch(selectColumn(left, tableStart)(tr))
    }
    return true
  }
}

/** YAZ-3696 D9: copy the selected body rows below the last of them. */
export const duplicateRows: Command = (state, dispatch) => {
  if (!isInTable(state)) return false
  const { table, tableStart, top, bottom } = selectedRect(state)
  if (top === 0) return false
  if (dispatch) {
    const rows: Node[] = []
    let pos = tableStart
    for (let index = 0; index < bottom; index++) {
      const row = table.child(index)
      if (index >= top) rows.push(row)
      pos += row.nodeSize
    }
    dispatch(state.tr.insert(pos, rows))
  }
  return true
}

export function useOperation(
  refs: Refs,
  ctx?: Ctx,
  getPos?: () => number | undefined
) {
  const {
    xLineHandleRef,
    contentWrapperRef,
    colHandleRef,
    rowHandleRef,
    hoverIndex,
    lineHoverIndex,
  } = refs

  const onAddRow = () => {
    if (!ctx) return
    const xHandle = xLineHandleRef.value
    if (!xHandle) return

    const [rowIndex] = lineHoverIndex.value!
    if (rowIndex < 0) return

    if (!ctx.get(editorViewCtx).editable) return

    const rows = Array.from(
      contentWrapperRef.value?.querySelectorAll('tr') ?? []
    )
    const commands = ctx.get(commandsCtx)
    const pos = (getPos?.() ?? 0) + 1
    if (rows.length === rowIndex) {
      commands.call(selectRowCommand.key, { pos, index: rowIndex - 1 })
      commands.call(addRowAfterCommand.key)
    } else {
      commands.call(selectRowCommand.key, { pos, index: rowIndex })
      commands.call(addRowBeforeCommand.key)
    }

    commands.call(selectRowCommand.key, { pos, index: rowIndex })
    xHandle.dataset.show = 'false'
  }

  const onAddCol = () => {
    if (!ctx) return
    const xHandle = xLineHandleRef.value
    if (!xHandle) return

    const [_, colIndex] = lineHoverIndex.value!
    if (colIndex < 0) return

    if (!ctx.get(editorViewCtx).editable) return

    const cols = Array.from(
      contentWrapperRef.value?.querySelector('tr')?.children ?? []
    )
    const commands = ctx.get(commandsCtx)

    const pos = (getPos?.() ?? 0) + 1
    if (cols.length === colIndex) {
      commands.call(selectColCommand.key, { pos, index: colIndex - 1 })
      commands.call(addColAfterCommand.key)
    } else {
      commands.call(selectColCommand.key, { pos, index: colIndex })
      commands.call(addColBeforeCommand.key)
    }

    commands.call(selectColCommand.key, { pos, index: colIndex })
  }

  const selectCol = () => {
    if (!ctx) return
    // YAZ-3696 R3: a read-only note opens no menu.
    if (!ctx.get(editorViewCtx).editable) return
    const [_, colIndex] = hoverIndex.value!
    const commands = ctx.get(commandsCtx)
    const pos = (getPos?.() ?? 0) + 1
    commands.call(selectColCommand.key, { pos, index: colIndex })
    const buttonGroup =
      colHandleRef.value?.querySelector<HTMLElement>('.button-group')
    if (buttonGroup)
      buttonGroup.dataset.show =
        buttonGroup.dataset.show === 'true' ? 'false' : 'true'
  }

  const selectRow = () => {
    if (!ctx) return
    // YAZ-3696 R3: a read-only note opens no menu.
    if (!ctx.get(editorViewCtx).editable) return
    const [rowIndex, _] = hoverIndex.value!
    const commands = ctx.get(commandsCtx)
    const pos = (getPos?.() ?? 0) + 1
    commands.call(selectRowCommand.key, { pos, index: rowIndex })
    const buttonGroup =
      rowHandleRef.value?.querySelector<HTMLElement>('.button-group')
    if (buttonGroup && rowIndex > 0)
      buttonGroup.dataset.show =
        buttonGroup.dataset.show === 'true' ? 'false' : 'true'
  }

  // A menu item acts on the selection the handle click made, closes the menus and gives the
  // focus back to the editor. Each command is one transaction (one undo step).
  const item = (label: string, run: (editor: Ctx) => void): MenuItem => [
    label,
    (e: PointerEvent) => {
      if (!ctx) return

      const view = ctx.get(editorViewCtx)
      if (!view.editable) return

      e.preventDefault()
      e.stopPropagation()
      run(ctx)
      for (const handle of [colHandleRef.value, rowHandleRef.value])
        handle?.querySelector('.button-group')?.setAttribute('data-show', 'false')
      requestAnimationFrame(() => {
        view.focus()
      })
    },
  ]
  const call = <T>(label: string, key: CmdKey<T>, payload?: T) =>
    item(label, (editor) => editor.get(commandsCtx).call(key, payload))
  const prose = (label: string, command: Command) =>
    item(label, (editor) => {
      const view = editor.get(editorViewCtx)
      command(view.state, view.dispatch)
    })

  // YAZ-3696 D9: the labeled menus, in groups (a separator between two groups).
  const colMenu: MenuItem[][] = [
    [
      call('Insert column left', addColBeforeCommand.key),
      call('Insert column right', addColAfterCommand.key),
    ],
    [
      call('Align left', setAlignCommand.key, 'left'),
      call('Align center', setAlignCommand.key, 'center'),
      call('Align right', setAlignCommand.key, 'right'),
    ],
    [prose('Sort A to Z', sortRows(1)), prose('Sort Z to A', sortRows(-1))],
    [
      prose('Clear column', deleteCellSelection),
      call('Delete column', deleteSelectedCellsCommand.key),
    ],
  ]
  const rowMenu: MenuItem[][] = [
    [
      call('Insert row above', addRowBeforeCommand.key),
      call('Insert row below', addRowAfterCommand.key),
      prose('Duplicate row', duplicateRows),
    ],
    [
      prose('Clear row', deleteCellSelection),
      call('Delete row', deleteSelectedCellsCommand.key),
    ],
  ]

  return {
    onAddRow,
    onAddCol,
    selectCol,
    selectRow,
    colMenu,
    rowMenu,
  }
}
