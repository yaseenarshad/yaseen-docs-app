import type { Ctx } from '@milkdown/ctx'

import { commandsCtx, editorViewCtx } from '@milkdown/core'
import { selectColCommand, selectRowCommand } from '@milkdown/preset-gfm'
import { CellSelection, TableMap, selectedRect } from '@milkdown/prose/tables'

import type { Refs } from './types'

/**
 * YAZ-3820: a handle click or right-click asks the app for its table menu with this event, sent
 * on the handle (it bubbles to the editor's DOM). The block has no menu of its own: the app's note
 * menu opens at `x`, `y`, as on a right-click in the cell at `pos` (a cell of the handle's
 * column in row 1, or of its row in column A), on the cells the click selected.
 */
export const TABLE_HANDLE_MENU = 'milkdown-table-handle-menu'
export interface TableHandleMenuDetail {
  x: number
  y: number
  pos: number
}

export function useOperation(
  refs: Refs,
  ctx?: Ctx,
  getPos?: () => number | undefined
) {
  const { colHandleRef, rowHandleRef, hoverIndex } = refs

  /**
   * YAZ-3801: what a handle click (left or right) selects. A selection of whole columns (rows)
   * that holds the hovered one stays, so the menu acts on all of them; a row selection stays only
   * without the header row. Shift grows the selection to the hovered column (row), as in Sheets.
   * Else the hovered column (row) alone. Then the app's menu opens (YAZ-3820); the header row has
   * no row menu.
   */
  const select = (kind: 'col' | 'row', e: MouseEvent) => {
    if (!ctx) return
    const view = ctx.get(editorViewCtx)
    // YAZ-3696 R3: a read-only note opens no menu.
    if (!view.editable) return
    const [rowIndex, colIndex] = hoverIndex.value!
    const pos = (getPos?.() ?? 0) + 1
    const { selection } = view.state
    const own =
      selection instanceof CellSelection &&
      selection.$anchorCell.start(-1) === pos
    const rect = own ? selectedRect(view.state) : undefined
    const keep =
      own &&
      rect &&
      (kind === 'col'
        ? selection.isColSelection() &&
          rect.left <= colIndex &&
          colIndex < rect.right
        : selection.isRowSelection() &&
          rect.top > 0 &&
          rect.top <= rowIndex &&
          rowIndex < rect.bottom)
    if (own && rect && e.shiftKey) {
      const index = kind === 'col' ? colIndex : rowIndex
      const $head = view.state.doc.resolve(
        pos +
          rect.map.positionAt(
            kind === 'col' ? 0 : index,
            kind === 'col' ? index : 0,
            rect.table
          )
      )
      const grown =
        kind === 'col'
          ? CellSelection.colSelection(selection.$anchorCell, $head)
          : CellSelection.rowSelection(selection.$anchorCell, $head)
      view.dispatch(view.state.tr.setSelection(grown))
    } else if (!keep) {
      ctx
        .get(commandsCtx)
        .call(kind === 'col' ? selectColCommand.key : selectRowCommand.key, {
          pos,
          index: kind === 'col' ? colIndex : rowIndex,
        })
    }
    const table = view.state.doc.nodeAt(pos - 1)
    if (!table || (kind === 'row' && rowIndex === 0)) return
    const detail: TableHandleMenuDetail = {
      x: e.clientX,
      y: e.clientY,
      pos:
        pos +
        TableMap.get(table).positionAt(
          kind === 'col' ? 0 : rowIndex,
          kind === 'col' ? colIndex : 0,
          table
        ),
    }
    ;(kind === 'col' ? colHandleRef : rowHandleRef).value?.dispatchEvent(
      new CustomEvent(TABLE_HANDLE_MENU, { bubbles: true, detail })
    )
  }

  return {
    selectCol: (e: MouseEvent) => select('col', e),
    selectRow: (e: MouseEvent) => select('row', e),
  }
}
