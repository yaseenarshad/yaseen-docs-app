import type { Ctx } from '@milkdown/ctx'
import type { Node } from '@milkdown/prose/model'
import type { Command, EditorState } from '@milkdown/prose/state'

import { commandsCtx, editorViewCtx, type CmdKey } from '@milkdown/core'
import {
  deleteSelectedCellsCommand,
  selectCol as selectColumn,
  selectColCommand,
  selectRowCommand,
  setAlignCommand,
} from '@milkdown/preset-gfm'
import { closeHistory } from '@milkdown/prose/history'
import {
  CellSelection,
  addColumn,
  deleteCellSelection,
  isInTable,
  selectedRect,
} from '@milkdown/prose/tables'

import type { Refs } from './types'

/**
 * One labeled menu item (YAZ-3696 D9): its text for the number of selected columns or rows
 * (YAZ-3801), what a pointerdown on it does, and when it is disabled.
 */
export type MenuItem = [
  label: (count: number) => string,
  onPointerdown: (e: PointerEvent) => void,
  disabled?: (state: EditorState) => boolean,
]

// YAZ-3696 D9: as the note's right-click menu, the last body row and the last column are never
// deleted (GFM needs a header row and one row; the table needs one column).
const allBodyRows = (state: EditorState) => {
  if (!isInTable(state)) return true
  const { top, bottom, map } = selectedRect(state)
  return top === 0 || bottom - top >= map.height - 1
}
const allColumns = (state: EditorState) => {
  if (!isInTable(state)) return true
  const { left, right, map } = selectedRect(state)
  return right - left >= map.width
}

// "9" before "10"; case and accents do not count.
const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' })

/**
 * YAZ-3696 D9: sort the body rows by the text of the selected column. The header row stays
 * first, empty cells go last, equal cells keep their order. The whole rows move, so each cell
 * keeps its attributes. One transaction, which selects the column again. GFM cells have no
 * colspan, so the column is the cell index in each row.
 */
export function sortRows(direction: 1 | -1): Command {
  return (state, dispatch) => {
    if (!isInTable(state)) return false
    const { table, tableStart, left } = selectedRect(state)
    const rows: Node[] = []
    table.forEach((row, _, index) => {
      if (index > 0) rows.push(row)
    })
    const sorted = rows
      .map((row, index) => ({ row, index, text: row.child(left).textContent.trim() }))
      .sort((a, b) => {
        if (!a.text !== !b.text) return a.text ? -1 : 1
        return direction * collator.compare(a.text, b.text) || a.index - b.index
      })
      .map(({ row }) => row)
    if (sorted.every((row, index) => row === rows[index])) return true
    if (dispatch) {
      const from = tableStart + table.firstChild!.nodeSize
      const tr = state.tr.replaceWith(from, tableStart + table.content.size, sorted)
      dispatch(selectColumn(left, tableStart)(tr))
    }
    return true
  }
}

/** YAZ-3696 D9: copy the selected body rows below the last of them. */
export const duplicateRows: Command = (state, dispatch) => {
  if (!isInTable(state)) return false
  const { table, tableStart, top, bottom } = selectedRect(state)
  if (top === 0) return false
  if (dispatch) {
    const rows: Node[] = []
    let pos = tableStart
    for (let index = 0; index < bottom; index++) {
      const row = table.child(index)
      if (index >= top) rows.push(row)
      pos += row.nodeSize
    }
    dispatch(state.tr.insert(pos, rows))
  }
  return true
}

/**
 * YAZ-3801: insert as many columns as the selection holds, left or right of it, in one
 * transaction (`addColumnBefore` and `addColumnAfter` of `prosemirror-tables` insert one). The
 * same cells stay selected: a mapped column selection of a one-column table is also a row
 * selection, and `CellSelection.map` grew it over the new columns.
 */
export function insertColumns(side: 'left' | 'right'): Command {
  return (state, dispatch) => {
    if (!isInTable(state)) return false
    if (dispatch) {
      const rect = selectedRect(state)
      const at = side === 'left' ? rect.left : rect.right
      // `addColumn` maps the rect's positions through the transaction's steps.
      const tr = state.tr
      for (let i = rect.left; i < rect.right; i++) addColumn(tr, rect, at)
      const { selection } = state
      if (selection instanceof CellSelection) {
        const cell = (pos: number) => tr.doc.resolve(tr.mapping.map(pos))
        tr.setSelection(
          new CellSelection(
            cell(selection.$anchorCell.pos),
            cell(selection.$headCell.pos)
          )
        )
      }
      dispatch(tr)
    }
    return true
  }
}

/**
 * YAZ-3801: insert as many body rows as the selection holds, above or below it, in one
 * transaction. Each cell takes its column's alignment, as GFM's `addRowWithAlignment` does.
 */
export function insertRows(side: 'above' | 'below'): Command {
  return (state, dispatch) => {
    if (!isInTable(state)) return false
    const { table, tableStart, map, top, bottom } = selectedRect(state)
    const at = side === 'above' ? top : bottom
    if (at === 0) return false
    if (dispatch) {
      let pos = tableStart
      for (let i = 0; i < at; i++) pos += table.child(i).nodeSize
      const { table_row: rowType, table_cell: cellType } = state.schema.nodes
      const rows = Array.from({ length: bottom - top }, () =>
        rowType!.create(
          null,
          Array.from({ length: map.width }, (_, col) =>
            cellType!.createAndFill({
              alignment: table.nodeAt(map.map[col]!)?.attrs.alignment,
            })!
          )
        )
      )
      dispatch(state.tr.insert(pos, rows))
    }
    return true
  }
}

/** YAZ-3801: "Delete column" for one, "Delete 3 columns" for three. */
const counted =
  (one: string, many: (count: number) => string) => (count: number) =>
    count > 1 ? many(count) : one

export function useOperation(
  refs: Refs,
  ctx?: Ctx,
  getPos?: () => number | undefined
) {
  const { colHandleRef, rowHandleRef, hoverIndex } = refs

  /**
   * YAZ-3801: what a handle click (left or right) selects. A selection of whole columns (rows)
   * that holds the hovered one stays, so the menu acts on all of them; a row selection stays only
   * without the header row. Shift grows the selection to the hovered column (row), as in Sheets.
   * Else the hovered column (row) alone. Then the menu opens (`open`), or toggles on a left click.
   */
  const select = (kind: 'col' | 'row', e: MouseEvent, open: boolean) => {
    if (!ctx) return
    const view = ctx.get(editorViewCtx)
    // YAZ-3696 R3: a read-only note opens no menu.
    if (!view.editable) return
    const [rowIndex, colIndex] = hoverIndex.value!
    const pos = (getPos?.() ?? 0) + 1
    const { selection } = view.state
    const own =
      selection instanceof CellSelection &&
      selection.$anchorCell.start(-1) === pos
    const rect = own ? selectedRect(view.state) : undefined
    const keep =
      own &&
      rect &&
      (kind === 'col'
        ? selection.isColSelection() &&
          rect.left <= colIndex &&
          colIndex < rect.right
        : selection.isRowSelection() &&
          rect.top > 0 &&
          rect.top <= rowIndex &&
          rowIndex < rect.bottom)
    if (own && rect && e.shiftKey) {
      const index = kind === 'col' ? colIndex : rowIndex
      const $head = view.state.doc.resolve(
        pos +
          rect.map.positionAt(
            kind === 'col' ? 0 : index,
            kind === 'col' ? index : 0,
            rect.table
          )
      )
      const grown =
        kind === 'col'
          ? CellSelection.colSelection(selection.$anchorCell, $head)
          : CellSelection.rowSelection(selection.$anchorCell, $head)
      view.dispatch(view.state.tr.setSelection(grown))
    } else if (!keep) {
      ctx
        .get(commandsCtx)
        .call(kind === 'col' ? selectColCommand.key : selectRowCommand.key, {
          pos,
          index: kind === 'col' ? colIndex : rowIndex,
        })
    }
    const buttonGroup = (
      kind === 'col' ? colHandleRef : rowHandleRef
    ).value?.querySelector<HTMLElement>('.button-group')
    if (buttonGroup && (kind === 'col' || rowIndex > 0)) {
      buttonGroup.dataset.show =
        open || buttonGroup.dataset.show !== 'true' ? 'true' : 'false'
      refresh(buttonGroup, kind === 'col' ? colMenu : rowMenu, kind, ctx)
    }
  }
  const selectCol = (e: MouseEvent) => select('col', e, false)
  const selectRow = (e: MouseEvent) => select('row', e, false)
  // YAZ-3801: a right-click on a handle opens its menu, not the note's text menu.
  const openCol = (e: MouseEvent) => select('col', e, true)
  const openRow = (e: MouseEvent) => select('row', e, true)

  // YAZ-3696 D9, YAZ-3801: on open, each item's button gets its label for the number of selected
  // columns (rows), and is disabled when the item cannot act on the selection. The buttons are
  // the menu's items, in order.
  const refresh = (
    group: HTMLElement,
    menu: MenuItem[][],
    kind: 'col' | 'row',
    editor: Ctx
  ) => {
    const { state } = editor.get(editorViewCtx)
    let count = 1
    if (isInTable(state)) {
      const { left, right, top, bottom } = selectedRect(state)
      count = kind === 'col' ? right - left : bottom - top
    }
    const buttons = group.querySelectorAll('button')
    menu.flat().forEach(([label, , disabled], index) => {
      const button = buttons[index]
      if (!button) return
      button.textContent = label(count)
      button.disabled = disabled?.(state) ?? false
    })
  }

  // A menu item acts on the selection the handle click made, closes the menus and gives the
  // focus back to the editor. Each command is one transaction, after a closed history: one undo
  // step of its own (YAZ-3696 R4).
  const item = (
    label: string | ((count: number) => string),
    run: (editor: Ctx) => void,
    disabled?: (state: EditorState) => boolean
  ): MenuItem => [
    typeof label === 'string' ? () => label : label,
    (e: PointerEvent) => {
      if (!ctx) return

      const view = ctx.get(editorViewCtx)
      if (!view.editable) return

      e.preventDefault()
      e.stopPropagation()
      if (disabled?.(view.state)) return
      view.dispatch(closeHistory(view.state.tr))
      run(ctx)
      for (const handle of [colHandleRef.value, rowHandleRef.value])
        handle?.querySelector('.button-group')?.setAttribute('data-show', 'false')
      requestAnimationFrame(() => {
        view.focus()
      })
    },
    disabled,
  ]
  const call = <T>(
    label: string | ((count: number) => string),
    key: CmdKey<T>,
    payload?: T,
    disabled?: (state: EditorState) => boolean
  ) =>
    item(label, (editor) => editor.get(commandsCtx).call(key, payload), disabled)
  const prose = (label: string | ((count: number) => string), command: Command) =>
    item(label, (editor) => {
      const view = editor.get(editorViewCtx)
      command(view.state, view.dispatch)
    })

  // YAZ-3696 D9: the labeled menus, in groups (a separator between two groups). YAZ-3801: the
  // labels count the selected columns (rows), as in Sheets.
  const colMenu: MenuItem[][] = [
    [
      prose(
        counted('Insert column left', (n) => `Insert ${n} columns left`),
        insertColumns('left')
      ),
      prose(
        counted('Insert column right', (n) => `Insert ${n} columns right`),
        insertColumns('right')
      ),
    ],
    [
      call('Align left', setAlignCommand.key, 'left'),
      call('Align center', setAlignCommand.key, 'center'),
      call('Align right', setAlignCommand.key, 'right'),
    ],
    [prose('Sort A to Z', sortRows(1)), prose('Sort Z to A', sortRows(-1))],
    [
      prose(
        counted('Clear column', (n) => `Clear ${n} columns`),
        deleteCellSelection
      ),
      call(
        counted('Delete column', (n) => `Delete ${n} columns`),
        deleteSelectedCellsCommand.key,
        undefined,
        allColumns
      ),
    ],
  ]
  const rowMenu: MenuItem[][] = [
    [
      prose(
        counted('Insert row above', (n) => `Insert ${n} rows above`),
        insertRows('above')
      ),
      prose(
        counted('Insert row below', (n) => `Insert ${n} rows below`),
        insertRows('below')
      ),
      prose(
        counted('Duplicate row', (n) => `Duplicate ${n} rows`),
        duplicateRows
      ),
    ],
    [
      prose(
        counted('Clear row', (n) => `Clear ${n} rows`),
        deleteCellSelection
      ),
      call(
        counted('Delete row', (n) => `Delete ${n} rows`),
        deleteSelectedCellsCommand.key,
        undefined,
        allBodyRows
      ),
    ],
  ]

  return {
    selectCol,
    selectRow,
    openCol,
    openRow,
    colMenu,
    rowMenu,
  }
}
