import type { EditorView } from '@milkdown/prose/view'

import { throttle } from 'lodash-es'

import type { Refs } from './types'

import {
  computeColHandlePositionByIndex,
  computeRowHandlePositionByIndex,
  findPointerIndex,
  getRelatedDOM,
} from './utils'

function createPointerMoveHandler(
  refs: Refs,
  view?: EditorView
): (e: PointerEvent) => void {
  return throttle((e: PointerEvent) => {
    if (!view?.editable) return
    const {
      contentWrapperRef,
      yLineHandleRef,
      xLineHandleRef,
      colHandleRef,
      rowHandleRef,
      hoverIndex,
    } = refs
    const yHandle = yLineHandleRef.value
    if (!yHandle) return
    const xHandle = xLineHandleRef.value
    if (!xHandle) return
    const rowHandle = rowHandleRef.value
    if (!rowHandle) return
    const colHandle = colHandleRef.value
    if (!colHandle) return

    const index = findPointerIndex(e, view)
    if (!index) return

    const dom = getRelatedDOM(contentWrapperRef, index)
    if (!dom) return

    const rowButtonGroup = rowHandle.querySelector<HTMLElement>('.button-group')
    const colButtonGroup = colHandle.querySelector<HTMLElement>('.button-group')
    if (rowButtonGroup) rowButtonGroup.dataset.show = 'false'
    if (colButtonGroup) colButtonGroup.dataset.show = 'false'

    // YAZ-3800 (2D): no "+" insert line at a cell edge (insert is in the handle menus). The two
    // lines are only the drop line of a row or column drag (`drag-over-handler.ts`).
    yHandle.dataset.show = 'false'
    xHandle.dataset.show = 'false'
    rowHandle.dataset.show = 'true'
    colHandle.dataset.show = 'true'

    computeRowHandlePositionByIndex({
      refs,
      index,
    })
    computeColHandlePositionByIndex({
      refs,
      index,
    })
    hoverIndex.value = index
  }, 20)
}

function createPointerLeaveHandler(refs: Refs): () => void {
  return () => {
    const { rowHandleRef, colHandleRef, yLineHandleRef, xLineHandleRef } = refs
    setTimeout(() => {
      const rowHandle = rowHandleRef.value
      if (!rowHandle) return
      const colHandle = colHandleRef.value
      if (!colHandle) return
      const yHandle = yLineHandleRef.value
      if (!yHandle) return
      const xHandle = xLineHandleRef.value
      if (!xHandle) return

      rowHandle.dataset.show = 'false'
      colHandle.dataset.show = 'false'
      yHandle.dataset.show = 'false'
      xHandle.dataset.show = 'false'
    }, 200)
  }
}

// YAZ-4170: the app sends this on the table block when it moves a pinned header row (`tableFreeze.ts`
// in the app has its own copy of the name): the handles follow it.
export const TABLE_HANDLE_PLACE = 'milkdown-table-handle-place'

export function usePointerHandlers(refs: Refs, view?: EditorView) {
  const move = createPointerMoveHandler(refs, view)
  const pointerLeave = createPointerLeaveHandler(refs)
  // YAZ-4169: the handles sit in the note's coordinates (their containing block is `.ProseMirror`),
  // outside the block's sideways scroll. A scroll moves the cells under a still pointer and sends no
  // pointer move, so the handles stayed over another column. `pointerReplay` (the block's `scroll`)
  // runs the last pointer move again while the handles show: they go to the cell now under the pointer.
  let last: PointerEvent | undefined
  const pointerMove = (e: PointerEvent) => {
    last = e
    move(e)
  }
  const pointerReplay = () => {
    if (last && refs.colHandleRef.value?.dataset.show === 'true') move(last)
  }

  return {
    pointerMove,
    pointerLeave,
    pointerReplay,
  }
}
