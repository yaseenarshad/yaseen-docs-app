export type SlashMenuItem = {
    label: string;
    icon: string;
    /** YAZ-3550: more words the filter matches besides the label. */
    keywords?: string[];
};
//# sourceMappingURL=utils.d.ts.map