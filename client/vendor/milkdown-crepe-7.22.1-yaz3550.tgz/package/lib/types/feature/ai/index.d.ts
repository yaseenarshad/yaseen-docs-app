import type { DefineFeature } from '../shared';
import type { AIFeatureConfig } from './types';
export type { AIDiffActionsConfig, AIFeatureConfig, AIPromptContext, AIProvider, AIStreamingIndicatorConfig, AISubmenuBuilder, AISubmenuDef, AISuggestionItem, AISuggestionsBuilder, } from './types';
export type { AIProviderConfigValue } from './commands';
export { runAICmd, abortAICmd, useAIProviderConfig } from './commands';
export { defaultBuildContext } from './context';
export type { AIInstructionTooltipAPI } from './instruction-tooltip';
export { useAIInstructionTooltipAPI } from './instruction-tooltip';
export { aiIcon as defaultAIIcon } from '../../icons';
export declare const ai: DefineFeature<AIFeatureConfig>;
//# sourceMappingURL=index.d.ts.map