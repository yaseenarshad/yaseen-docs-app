import type { GroupBuilder } from '../../utils';
import type { DefineFeature } from '../shared';
import type { ToolbarItem } from './config';
export { keymapRef } from '../../utils/keyboard-shortcut';
export type { KeymapRef } from '../../utils/keyboard-shortcut';
export type { ToolbarItem } from './config';
interface ToolbarConfig {
    boldIcon: string;
    codeIcon: string;
    italicIcon: string;
    linkIcon: string;
    strikethroughIcon: string;
    latexIcon: string;
    aiIcon: string;
    boldLabel: string;
    codeLabel: string;
    italicLabel: string;
    linkLabel: string;
    strikethroughLabel: string;
    latexLabel: string;
    aiLabel: string;
    buildToolbar: (builder: GroupBuilder<ToolbarItem>) => void;
}
export type ToolbarFeatureConfig = Partial<ToolbarConfig>;
export declare const toolbar: DefineFeature<ToolbarFeatureConfig>;
//# sourceMappingURL=index.d.ts.map