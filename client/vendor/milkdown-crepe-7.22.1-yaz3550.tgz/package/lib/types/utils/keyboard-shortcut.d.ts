import type { Ctx, SliceType } from '@milkdown/kit/ctx';
import type { KeymapConfig } from '@milkdown/kit/utils';
export interface KeymapRef {
    slice: SliceType<KeymapConfig<string>>;
    entry: string;
}
export declare function keymapRef<K extends string>(slice: SliceType<KeymapConfig<K>>, entry: K): KeymapRef;
export interface ResolvedShortcut {
    display: string;
    aria: string;
}
export declare function formatKeymapShortcut(shortcut: string, mac: boolean): ResolvedShortcut;
export declare function resolveKeymapShortcut(ctx: Ctx, ref: KeymapRef): ResolvedShortcut | undefined;
//# sourceMappingURL=keyboard-shortcut.d.ts.map