export {};
//# sourceMappingURL=keyboard-shortcut.spec.d.ts.map